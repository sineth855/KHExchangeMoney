<template>
  <footer class="app-footer">
    <a href="http://khland.biz">KHLand Co.,Ltd</a> &copy; 2018.All Right Reserved.
    <span class="float-right">Powered by <a href="#">SG Teams</a></span>
  </footer>
</template>
<script>
export default {
  name: 'footer'
}
</script>
